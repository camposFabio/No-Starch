def isEvenIterative(num):
    return num % 2 == 0