def shortest():
    shortest()

shortest()