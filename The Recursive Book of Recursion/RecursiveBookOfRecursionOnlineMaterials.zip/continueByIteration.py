i = 0 # Start i at 0.
while i < 4: # Stops when false.
    # The main code:
    if i == 2: # The continue condition.
        continue
    print(i, 'Hello!')
    i = i + 1 # Increment i.

